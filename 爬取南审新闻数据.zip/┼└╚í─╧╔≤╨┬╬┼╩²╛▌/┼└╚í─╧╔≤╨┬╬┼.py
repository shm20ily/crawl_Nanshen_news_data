import requests
from bs4 import BeautifulSoup
import xlwt
from PIL import Image
import cv2
import numpy as np
import os


def get_response(url, headers={'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}):
    try:
        req = requests.get(url, headers=headers, timeout=30)
        req.raise_for_status()  # 如果status_code!=200,则抛出异常
        req.encoding = req.apparent_encoding
        return req
    except Exception as e:
        print('抓取出错')
        print(e)
        return None


def find_news_urls(soup):
    tags = soup.select('.news_title>a')
    urls = []
    for tag in tags:
        url = tag.get('href')
        if url[:4] == 'http':  # 是绝对路径
            url = url
        else:  # 是相对路径
            url = url0 + url
        urls.append(url)
    return urls


def get_news(url):
    req = get_response(url)
    soup = BeautifulSoup(req.text, 'html.parser')
    # 创建新闻存储字典
    news_dict = {}

    # 标题
    news_title = soup.select('.arti-title')[0].string.strip()  # 去掉头尾的空格等
    # 注意：这里用text和string等价。
    # string只返回当前标签中的文本，text还返回所有子标签中的文本
    # news_title = soup.find_all(attrs={'class':'arti-title'})[0].string.strip() #和上面的等价
    news_dict['title'] = news_title
    print('标题：' + news_title)

    # 来源
    news_src = soup.select('p>span.arti-info')[0].text.strip()[3:]
    news_dict['src'] = news_src
    print('来源：' + news_src)

    # 点击数 (是动态数据，用Javascript逆向工程爬取)
    news_click_tag = soup.select('#container > div > div > div > p > span.arti-views > span')[0]
    url_js = url0 + news_click_tag['url']
    headers = {"referer": url}
    qq = requests.post(url_js, headers=headers)
    news_dict['click'] = qq.text
    print('点击数：' + qq.text)

    # 日期
    news_day = soup.select('#container > div > div > div > p > span.arti-update')[0].text.strip()[5:]
    # soup.find_all(string=re.compile("[0-9]{4}\-[0-9]{2}\-[0-9]{2}"))
    news_dict['day'] = news_day
    print('发布时间：' + news_day)

    # 正文
    ps = soup.select('#container > div > div > div > div.entry > article > div > p')
    strs = ''
    for p in ps:
        para = p.text
        if para != None:
            strs += '\r\n    '  # 另起一行
            strs += para
    news_dict['contents'] = strs
    print(strs)

    # 图片
    tags = soup.select('#container > div > div')[0].find_all('img')
    imgs = []
    for tag in tags:
        url = tag.get('src')
        if url[:4] == 'http':  # 是绝对路径
            url = url
        else:  # 是相对路径
            url = url0 + url
        req = requests.get(url, headers=headers)
        imgs.append(req.content)
    news_dict['imgs'] = imgs

    return news_dict


def save_news(news_dict, sheet, i):
    keys = list(news_dict.keys())
    k = len(keys)
    for n in range(k - 1):
        sheet.write(i + 1, n, news_dict[keys[n]])
    if len(news_dict[keys[-1]]) != 0:  # 如果图片数量不为 0
        save_pics(news_dict[keys[-1]], i)
        sheet.write(i + 1, k - 1, len(news_dict[keys[-1]]))


def save_pics(imgs_byte, i):
    for j in range(len(imgs_byte)):
        img_array = cv2.imdecode(np.frombuffer(imgs_byte[j], np.uint8), cv2.IMREAD_COLOR)
        rgb_img = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
        img = Image.fromarray(rgb_img)
        img.save(r'南审新闻/南审新闻图片' + str(i + 1) + '-' + str(j) + '.jpg')


if __name__ == '__main__':
    book = xlwt.Workbook(encoding='utf-8')
    sheet = book.add_sheet('南审主页新闻')
    sheet.write(0, 0, '标题')
    sheet.write(0, 1, '来源')
    sheet.write(0, 2, '点击数')
    sheet.write(0, 3, '发布时间')
    sheet.write(0, 4, '文章内容')
    sheet.write(0, 5, '图片数量')

    if not os.path.exists('南审新闻'):
        os.makedirs('南审新闻')

    url0 = 'https://www.nau.edu.cn'
    req = get_response(url0)

    soup = BeautifulSoup(req.text, 'html.parser')
    urls = find_news_urls(soup)
    # print(urls)

    for i in range(len(urls)):
        print('爬取第' + str(i + 1) + '条新闻--------------------')
        news_dict = get_news(urls[i])
        save_news(news_dict, sheet, i)

    book.save(r"南审新闻/南审主页新闻.xls")
